package com.pojo;

import java.util.List;

public class DogGoods {
    private int id,classname;
    private String dogname,img,oldmoney,newmoney;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClassname() {
        return classname;
    }

    public void setClassname(int classname) {
        this.classname = classname;
    }

    public String getDogname() {
        return dogname;
    }

    public void setDogname(String dogname) {
        this.dogname = dogname;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getOldmoney() {
        return oldmoney;
    }

    public void setOldmoney(String oldmoney) {
        this.oldmoney = oldmoney;
    }

    public String getNewmoney() {
        return newmoney;
    }

    public void setNewmoney(String newmoney) {
        this.newmoney = newmoney;
    }


}
