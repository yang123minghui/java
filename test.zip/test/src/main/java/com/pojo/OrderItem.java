package com.pojo;

public class OrderItem {
    private int id,number,goodsID;
    private String name,ordernumber;

    public OrderItem() {
        super();
    }

    public OrderItem(int number, int goodsID, String name, String ordernumber) {
        this.number = number;
        this.goodsID = goodsID;
        this.name = name;
        this.ordernumber = ordernumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getGoodsID() {
        return goodsID;
    }

    public void setGoodsID(int goodsID) {
        this.goodsID = goodsID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(String ordernumber) {
        this.ordernumber = ordernumber;
    }
}
