package com.pojo;

public class Breeds {
    private int id,parent_class;
    private String dogname,img;
    private Dogclass dogclass;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParent_class() {
        return parent_class;
    }

    public void setParent_class(int parent_class) {
        this.parent_class = parent_class;
    }

    public String getDogname() {
        return dogname;
    }

    public void setDogname(String dogname) {
        this.dogname = dogname;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Dogclass getDogclass() {
        return dogclass;
    }

    public void setDogclass(Dogclass dogclass) {
        this.dogclass = dogclass;
    }

    @Override
    public String toString() {
        return "Breeds{" +
                "id=" + id +
                ", parent_class=" + parent_class +
                ", dogname='" + dogname + '\'' +
                ", img='" + img + '\'' +
                ", dogclass=" + dogclass +
                '}';
    }
}
