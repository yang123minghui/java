package com.info;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 拦截器（实现HandlerInterceptor接口及其重写方法）
 */
public class Interceptor implements HandlerInterceptor {
    /**
     *预处理（controller执行之前）
      * @param request
     * @param response
     * @param o
     * @return true : 放行执行下一个拦截器，如果没有执行controller中方法，false:不放行
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        System.out.print("*****预处理******");
        //功能：逻辑判断（过滤一些非法字符串或者验证是否登录）
//        String url = request.getParameter("url");
//        if (url.contains("你妈的")){
//            request.setAttribute("msg","填写违规****");
//            request.getRequestDispatcher("error.jsp").forward(request,response);
//        }
        return true;
    }

    /**
     * 后处理 controller执行之后执行的代码
     * @param request
     * @param response
     * @param o
     * @param modelAndView 可以设置跳转页面（）；
     * @throws Exception
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object o, ModelAndView modelAndView) throws Exception {
//        modelAndView.setViewName("error");
//        modelAndView.addObject("msg","interceptor");
        System.out.print("******controller执行之后在执行******");
    }

    /**
     * 页面跳转之后执行的操作【最后执行】
     * @param request
     * @param response
     * @param o
     * @param e
     * @throws Exception
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) throws Exception {
    System.out.print("---最后执行---");
    }
}
