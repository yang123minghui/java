package com.info;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//全局异常处理器
public class ExceptionResolver implements HandlerExceptionResolver {
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object o, Exception e) {
//        指定错误【可选】
//        U u=null;
//       if (e instanceof U){
//         u= (U) e;
//       }else{
//        u=new U("系统维修中....");
//       }
//       必须填写信息【反馈客户】
       ModelAndView mav=new ModelAndView();
       mav.setViewName("error");
       mav.addObject("msg",e);//Exception e没有指定错误具体类型时【抛出错误的信息】
       mav.addObject("url",request.getRequestURL());//获取错误路径
        return mav;
    }
}
