package com.info;

import java.util.List;
import java.util.Map;
import java.util.Random;
/*
自定义异常类
* */
public class U extends Exception{
   private  String msg;

    public U(String msg) {
        this.msg = msg;
    }
//    get、set方法

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
