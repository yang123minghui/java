package com.dao;

import com.pojo.DogDetails;
//狗详细细节
public interface DogDetailsMapper {
    DogDetails getDetails(String dogname);
}
