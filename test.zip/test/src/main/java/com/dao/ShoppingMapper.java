package com.dao;

import com.pojo.Shopping;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ShoppingMapper {
//    添加数据
    int addShopping(@Param("name")String name,@Param("goodsID")int goodsID,@Param("number") int number,@Param("date")String date);
//    查询goodsid是否存在
    Integer selectID(@Param("goodsID") Integer goodsID,@Param("name")String name);
//    更新数量加
    int updateID(@Param("goodsID") Integer goodsID,@Param("name")String name);
//    减
    int updateIDjiang(@Param("goodsID") Integer goodsID,@Param("name")String name);
//    所有购物车商品
    List<Shopping>ListShopping(String name);
    //    查询价格
    List<Shopping>queryprice(@Param("name")String name,@Param("goodsID")List goodsID);
}
