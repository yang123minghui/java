package com.dao;

import com.pojo.Breeds;

import java.util.List;
//首页轮换类别下的狗
public interface BreedsMapper {
   public List<Breeds>IdList(int parent_class);
}
