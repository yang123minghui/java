package com.dao;

import com.pojo.OrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderItemMapper {
//    保存数据
    int goodsitem(OrderItem orderItem);
    //    查询
    List<OrderItem> listAll(String ordernumber);
    //    删除订单
    int deleteOrderItem(String ordernumber);
}
