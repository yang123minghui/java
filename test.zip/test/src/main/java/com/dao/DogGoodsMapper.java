package com.dao;

import com.pojo.DogGoods;
import org.apache.ibatis.annotations.Param;

import java.util.List;
//商品狗表
public interface DogGoodsMapper {
    List<DogGoods>top10();
    List<DogGoods>list();
    DogGoods getId(int id);
    List<DogGoods> MultGetId(@Param("MultiId")List list);


}
