package com.dao;


import com.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {
   Integer login(@Param("name") String name,@Param("pwd")  String pwd);
   User queryuser(String name);
   int update(User user);
}
