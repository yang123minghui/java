package com.controller;

import com.pojo.DogDetails;
import com.service.DogDetailsService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DogDetailsController {
    @Autowired
    DogDetailsService dogDetailsService;
    @RequestMapping(value = "dogdetails")
    public String getDetails(@RequestParam("dogname") String dogname,@RequestParam("img")String img, Model model){
        DogDetails details = dogDetailsService.getDetails(dogname);
        model.addAttribute("dogDetails",details);
        model.addAttribute("img",img);
        return "details";
    }
}
