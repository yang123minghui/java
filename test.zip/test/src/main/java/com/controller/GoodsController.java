package com.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.pojo.DogGoods;
import com.service.DogGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class GoodsController {
    @Autowired
    DogGoodsService dogGoodsService;
//    全部商品页
    @RequestMapping("/allGoods")
    public String allGoods(@RequestParam(value = "pn",defaultValue = "1")Integer pn, Model model){
        PageHelper.startPage(pn,15);
        List<DogGoods> list = dogGoodsService.list();
        PageInfo pageInfo=new PageInfo(list,3);
        model.addAttribute("pageInfo",pageInfo);
        model.addAttribute("RequestUrl","allGoods");
        return "allGoods";
    }
}
