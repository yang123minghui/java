package com.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.info.ExceptionResolver;
import com.info.MSg;
import com.info.U;
import com.pojo.DogGoods;
import com.pojo.Order;
import com.pojo.OrderItem;
import com.service.*;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Controller
public class C {
    @Autowired
    OrderService orderService;
    @Autowired
    OrderItemService orderItemService;
    @Autowired
    UserService userService;
    @Autowired
    DogGoodsService dogGoodsService;
    @Autowired
    ShoppingService shoppingService;

//    传统图片上传
    @RequestMapping("fileupload")
    public String fileupload(HttpServletRequest request) throws Exception {
//        文件路径
        String realPath = request.getSession().getServletContext().getRealPath("/fileUploads/");
//        判断文件是否存在
        File file=new File(realPath);
        if (!file.exists()){
           file.mkdir();

        }
//        解析request对象，获取上传文件
//        创建工厂
        DiskFileItemFactory factory=new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        List<FileItem> fileItems = upload.parseRequest(request);
        for (FileItem item:fileItems)
        {
            if (item.isFormField()){
//                非文件上传（表单上传）
                System.out.print("success2");
            }else {
//                图片上传
                System.out.print("上传成功");
                //String filename = item.getName();
                String filename= Math.random()*10+".jpg";
                item.write(new File(realPath,filename));
                item.delete();

            }
        }
        return "success";
    }
//    springMVC图片上传
    @RequestMapping("fileupload2")
    public String fileupload2(@RequestParam("upload") MultipartFile[] upload, HttpServletRequest request, String username) throws Exception {
//        文件路径
        String realPath = request.getSession().getServletContext().getRealPath("/fileUploads/");
//        判断文件夹目录是否存在
        File file=new File(realPath);
        if (!file.exists()){
           file.mkdir(); //创建文件夹目录
        }
        for (int i=0;i<upload.length;i++){
            MultipartFile multipartFile=upload[i];
            String filename = multipartFile.getOriginalFilename();  //获取文件名
            multipartFile.transferTo(new File(realPath,filename));//两个参数1.路径2.文件名
        }
        return "success";
    }
    //    springMVC跨域图片上传
    @RequestMapping("fileupload3")
    public String fileupload3(MultipartFile upload) throws Exception {
//        跨域文件保存路径
        String path="http://localhost:8088/fileupload/uploads/";
        String filename=upload.getOriginalFilename();//获取图片名称
        Client client = Client.create();
        WebResource webResource = client.resource(path + filename);//图片资源上传位置
        webResource.put(upload.getBytes());//上传图片操作
        return "success";
    }
    @RequestMapping("error")
    public String error() throws Exception {
        try {
            int a=10/0;
        } catch (Exception e) {
            e.printStackTrace();
            throw new U("错误");
        }
        return "success";
    }
    @RequestMapping("interceptor")
    public String interceptor() {
       System.out.print("*****controller执行*******");
        return "success";
    }


}
