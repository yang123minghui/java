package com.controller;

import com.info.MSg;
import com.pojo.DogGoods;
import com.pojo.Order;
import com.pojo.OrderItem;
import com.pojo.Shopping;
import com.service.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class OrdersController {
    @Autowired
    OrderService orderService;
    @Autowired
    OrderItemService orderItemService;
    @Autowired
    UserService userService;
    @Autowired
    DogGoodsService dogGoodsService;
    @Autowired
    ShoppingService shoppingService;
//未结算订单
    @RequestMapping("Orders")
    public ModelAndView Orders(HttpServletRequest request){
        ModelAndView mav=new ModelAndView();
        String name= String.valueOf(request.getSession().getAttribute("username"));
        if (name!=null){

        List<Order> orders = orderService.listOrder(name);
        List<Integer>list=new ArrayList<>();
        //List<OrderItem>N=new ArrayList<>();

        List<String>ordernumber=new ArrayList<>();
        for (int i=0;i<orders.size();i++){
          ordernumber.add(orders.get(i).getOrdernumber());
        }
        List<Map>z=new ArrayList<>();
        int sum=0;
        List<DogGoods> dogGoods=null;
        List<Shopping> shopping=null;
        for(int i=0;i<ordernumber.size();i++){
            List<OrderItem> orderItems =orderItemService.listAll(ordernumber.get(i));
            Map map=new HashMap();
            map.put("ordernumber",ordernumber.get(i));
            map.put("timer",orders.get(i).getTimer());

            for (OrderItem orderItem:orderItems){
                list.add(orderItem.getGoodsID());
                dogGoods = dogGoodsService.MultGetId(list);
                //shopping = shoppingService.queryprice(name, list);
                //N.add(orderItem);
                map.put("dogGoods",dogGoods);


            }
            //        算总和
            for (int j=0;j<orderItems.size();j++){
                sum+= Integer.parseInt(dogGoods.get(j).getNewmoney())* orderItems.get(j).getNumber();
            }
            map.put("number",orderItems);
            map.put("sum",sum);
            z.add(map);
            list.clear();

            sum=0;
        }
        mav.setViewName("Order");
        mav.addObject("Order",z);
        mav.addObject("userInfo",userService.queryuser(name));
        return mav;
        }else{
            mav.setViewName("error");
            mav.addObject("msg","未登录");
            return mav;
        }
    }
    //已完成订单
    @RequestMapping("SuccessOrders")
    public ModelAndView SuccessOrders(HttpServletRequest request){
        ModelAndView mav=new ModelAndView();
        String name= String.valueOf(request.getSession().getAttribute("username"));
        if (name!=null){

            List<Order> orders = orderService.queryOrder(name,1);
            List<Integer>list=new ArrayList<>();
            //List<OrderItem>N=new ArrayList<>();

            List<String>ordernumber=new ArrayList<>();
            for (int i=0;i<orders.size();i++){
                ordernumber.add(orders.get(i).getOrdernumber());
            }
            List<Map>z=new ArrayList<>();
            int sum=0;
            List<DogGoods> dogGoods=null;
            List<Shopping> shopping=null;
            for(int i=0;i<ordernumber.size();i++){
                List<OrderItem> orderItems =orderItemService.listAll(ordernumber.get(i));
                Map map=new HashMap();
                map.put("ordernumber",ordernumber.get(i));
                map.put("timer",orders.get(i).getTimer());

                for (OrderItem orderItem:orderItems){
                    list.add(orderItem.getGoodsID());
                    dogGoods = dogGoodsService.MultGetId(list);
                    //shopping = shoppingService.queryprice(name, list);
                    //N.add(orderItem);
                    map.put("dogGoods",dogGoods);

                    //        算总和
                }

                for (int j=0;j<orderItems.size();j++){
                    sum+= Integer.parseInt(dogGoods.get(j).getNewmoney())* orderItems.get(j).getNumber();
                }
                map.put("number",orderItems);
                map.put("sum",sum);
                z.add(map);
                list.clear();

                sum=0;
            }
            mav.setViewName("SuccessOrder");
            mav.addObject("Order",z);
            mav.addObject("userInfo",userService.queryuser(name));
            return mav;
        }else{
            mav.setViewName("error");
            mav.addObject("msg","未登录");
            return mav;
        }
    }
//删除订单
    @ResponseBody
    @RequestMapping(value = "deleteOrdernumber/{ordernumber}",method = RequestMethod.DELETE)
    public MSg deleteOrdernumber(@PathVariable("ordernumber")String ordernumber){
        int i = orderService.deleteOrder(ordernumber);
        if (i>0){
            int i1 = orderItemService.deleteOrderItem(ordernumber);
            if (i1>0){
                return MSg.messages("成功",200);
            }
        }
        return MSg.messages("失败",100);
    }
//结算
    @RequestMapping(value = "jiesuang")
    public String jiesuang(@Param("ordernumber") String ordernumber){
        ModelAndView modelAndView=new ModelAndView();
        int i2 = orderService.updateOrder(ordernumber);
        if (i2>0){
         return  "Success2";
        }
        return "";
    }
}
