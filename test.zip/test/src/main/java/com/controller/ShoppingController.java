package com.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.info.MSg;
import com.pojo.DogGoods;
import com.pojo.Order;
import com.pojo.OrderItem;
import com.pojo.Shopping;
import com.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
public class ShoppingController {
    @Autowired
    ShoppingService shoppingService;

    @Autowired
    DogGoodsService dogGoodsService;
    @Autowired
    UserService userService;
    @Autowired
    OrderService orderService;
    @Autowired
    OrderItemService orderItemService;
//购入车加入
    @ResponseBody
    @RequestMapping(value = "EditShopping",method = RequestMethod.POST)
    public MSg EditShopping(@RequestParam("goodsID")int goodsID, HttpServletRequest request){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
//            获取商品对象
            DogGoods doggoods = dogGoodsService.getId(goodsID);
//            时间
            SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
            String format = simpleDateFormat.format(new Date());

//            判断是否存在
            Integer id = shoppingService.selectID(goodsID, name);
            //               存在跟新
            if (id>0){
                int i = shoppingService.updateID(goodsID, name);
                if(i>0)
                    return MSg.messages("加入成功",200);
                else
                    return MSg.messages("加入失败",100);


            }else {
//                不存在插入
                int i = shoppingService.addShopping(name, goodsID, 1, format);
                if (i>0)
                    return MSg.messages("加入成功",200);
                else
                    return MSg.messages("加入失败",100);
            }

        }else{
          return MSg.messages("未登录！添加失败",100);
        }
    }
//    购物车展示
    @RequestMapping("ShoppingCart")
    public String ShoppingCart(HttpServletRequest request,@RequestParam(value = "pn",defaultValue = "1")Integer pn, Model model){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            List<Shopping> shoppings = shoppingService.ListShopping(name);
            List<Integer> list=new ArrayList();
            List<Integer> number=new ArrayList();
            for (int i=0;i<shoppings.size();i++){
                list.add(shoppings.get(i).getGoodsID());
                number.add(shoppings.get(i).getNumber());
            }
            List<DogGoods> dogGoods = dogGoodsService.MultGetId(list);
           // dogGoods.add((DogGoods) number);
            PageHelper.startPage(pn, 3);
            PageInfo info=new PageInfo(dogGoods,3);
            model.addAttribute("info",info);
            model.addAttribute("number",number);//传递两个参数，varstatus="loop"前端使用${number[loop.index]}
            return "shopping";
        }else
        return "forward:/index";
    }
//    购物车添加商品数量
    @ResponseBody
    @RequestMapping( value = "addnumber",method = RequestMethod.POST)
    public MSg addnumber(@RequestParam("goodID")Integer goodsID,HttpServletRequest request){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            int i = shoppingService.updateID(goodsID, name);
            if(i>0)
                return MSg.messages("修改成功",200);
            else
                return MSg.messages("修改失败",100);
        }else
            return MSg.messages("亲！请重新登录",300);
    }
    //    减少数量
    @ResponseBody
    @RequestMapping( value = "delnumber",method = RequestMethod.POST)
    public MSg delnumber(@RequestParam("goodID")Integer goodsID,HttpServletRequest request){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            int i = shoppingService.updateIDjiang(goodsID, name);
            if(i>0)
                return MSg.messages("修改成功",200);
            else
                return MSg.messages("修改失败",100);
        }else
            return MSg.messages("亲！请重新登录",300);
    }
    //    下订单
    @ResponseBody
    @RequestMapping( value = "buygoods")
    public ModelAndView buygoods(@RequestParam(value = "info")String s, HttpServletRequest request){
        String name= (String) request.getSession().getAttribute("username");
        String[] info=s.split(",");
        ModelAndView modelAndView=new ModelAndView();
        List<Integer>list=new ArrayList<>();
        int sum=0;
//        取出传递的金额商品id
        for (int i=0;i<info.length-1;i++){
           list.add(Integer.parseInt(info[i]));
        }
        List<DogGoods> dogGoods = dogGoodsService.MultGetId(list);
        List<Shopping> shopping = shoppingService.queryprice(name, list);
        List<Integer>number=new ArrayList<>();
        for (int i=0;i<shopping.size();i++){
            number.add(shopping.get(i).getNumber());
        }
//        算总和
        for (int i=0;i<shopping.size();i++){
            sum+= Integer.parseInt(dogGoods.get(i).getNewmoney())* shopping.get(i).getNumber();
        }

//        验证合计与总和的金额是否相同
        if (sum==Integer.parseInt(info[info.length-1])){

            SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timer = format.format(new Date());
            String rand= String.valueOf((int)(Math.random()*1000000+10000000));
            for (int i=0;i<number.size();i++){
                OrderItem orderItem=new OrderItem(number.get(i),list.get(i),name,rand);
                orderItemService.goodsitem(orderItem);
            }

            Order order=new Order(0,name,rand,timer);
            orderService.baocun(order);
            modelAndView.setViewName("Settlement");
            modelAndView.addObject("dogInfo",dogGoods);
            modelAndView.addObject("userInfo",userService.queryuser(name));
            modelAndView.addObject("number",shopping);
            modelAndView.addObject("heji",info[info.length-1]);
            modelAndView.addObject("ordernumber",rand);

            return modelAndView;
        }else
        return null;
    }
    //    单个商品下订单
    @ResponseBody
    @RequestMapping( value = "singleBuyGoods")
    public MSg singleBuyGoods(@RequestParam( "goodsID")Integer goodsID,@RequestParam("newmoney") String newmoney, HttpServletRequest request){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            List<Integer>list=new ArrayList<>();
//        取出传递的金额商品id

            list.add(goodsID);
            DogGoods dogGoods = dogGoodsService.getId(goodsID);
            int sum = Integer.parseInt(dogGoods.getNewmoney())* 1;

            System.out.print("sum="+sum+",newmoney="+newmoney);
//        验证合计与总和的金额是否相同
            if (sum==Integer.parseInt(newmoney)){

                SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String timer = format.format(new Date());
                String rand= String.valueOf((int)(Math.random()*1000000+10000000));

                OrderItem orderItem=new OrderItem(1,goodsID,name,rand);
                orderItemService.goodsitem(orderItem);


                Order order=new Order(0,name,rand,timer);
                orderService.baocun(order);

                return MSg.messages("成功",200);
            }else
                return MSg.messages("非法操作",100);
        }else{
            return MSg.messages("未登录",100);
        }

    }


}
