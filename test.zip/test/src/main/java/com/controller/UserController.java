package com.controller;

import com.dao.UserMapper;
import com.info.MSg;
import com.pojo.User;
import com.service.UserService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;

@Controller
public class UserController {
        @Autowired
        UserService userService;
//@RequestMapping(value="/cors/addProduct",method= RequestMethod.POST)
//@ResponseBody
//public ModelAndView addProduct( MultipartFile pictureFile, HttpServletRequest request) throws IllegalStateException, IOException {
////获取文件名
//String name=pictureFile.getOriginalFilename();
////设置图片上传路径（设置文件webapp下面的upload）
// String url = request.getSession().getServletContext().getRealPath("/src/main/webapp/upload");
//System.out.println("路径3："+url);
////以绝对路径保存重名命后的图片
// pictureFile.transferTo(new File(url+"/"+name));
//
//return new ModelAndView("redirect:/index");
//    }
    @ResponseBody
    @RequestMapping("login")
    public MSg login(User user, HttpServletRequest request){
        Integer login = userService.login(user.getName(), user.getPwd());
        if (login>0){
            request.getSession().setAttribute("username", user.getName());
            return MSg.messages("登录成功",200);
        }else
        return MSg.messages("登录失败",100);
    }
    @RequestMapping("loginout")
    public String login(HttpServletRequest request){
        request.getSession().removeAttribute("username");
        return "forward:/index";
    }
    @RequestMapping("UserInfo")
    public String UserInfo(HttpServletRequest request,Model model){
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            User queryuser = userService.queryuser(name);
            model.addAttribute("info",queryuser);
            System.out.print("已经登录");
         return "UserSet";
        }else{
            System.out.print("未登录");
            model.addAttribute("msg","未登录");
            return "error";
        }

    }
    @ResponseBody
    @RequestMapping("UserInfoUpdate")
    public MSg UserInfoUpdate(User user,HttpServletRequest request){
        System.out.print("kkkkk=");
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            int update = userService.update(user);
            if (update>0){
                return MSg.messages("成功",200);
            }else
            return MSg.messages("失败",100);
        }else{

            return MSg.messages("未登录",100);
        }


    }
    @ResponseBody
    @RequestMapping("UserInfoUpdate2")
    public MSg UserInfoUpdate2(@RequestBody User user,HttpServletRequest request){
        System.out.print("kkkkk=");
        String name= (String) request.getSession().getAttribute("username");
        if (name!=null){
            int update = userService.update(user);
            if (update>0){
                return MSg.messages("成功",200);
            }else
            return MSg.messages("失败",100);
        }else{

            return MSg.messages("未登录",100);
        }


    }

}
