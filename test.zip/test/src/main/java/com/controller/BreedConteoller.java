package com.controller;

import com.service.BreedService;
import com.service.DogGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BreedConteoller {
    @Autowired
    BreedService breedService;
//    商品
    @Autowired
    DogGoodsService dogGoodsService;
//    首页
    @RequestMapping(value="/index")
    public String index(Model model){
        model.addAttribute("a1", breedService.IdList(1));
        model.addAttribute("a2", breedService.IdList(2));
        model.addAttribute("a3", breedService.IdList(3));
        model.addAttribute("goods",dogGoodsService.top10());
        model.addAttribute("RequestUrl","index");
        return "index";
    }
}
