package com.service;

import com.pojo.OrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderItemService {
//    保存
    int goodsitem(OrderItem orderItem);
    //    查询
    List<OrderItem> listAll(String ordernumber);
    //    删除订单
    int deleteOrderItem(String ordernumber);
}
