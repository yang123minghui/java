package com.service.Impl;

import com.dao.DogDetailsMapper;
import com.pojo.DogDetails;
import com.service.DogDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DogDetailsServiceImpl implements DogDetailsService {

    @Autowired
    DogDetailsMapper dogDetailsMapper;

    @Override
    public DogDetails getDetails(String dogname) {
        return dogDetailsMapper.getDetails(dogname);
    }
}
