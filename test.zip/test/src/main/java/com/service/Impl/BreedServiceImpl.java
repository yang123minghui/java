package com.service.Impl;

import com.dao.BreedsMapper;
import com.pojo.Breeds;
import com.service.BreedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BreedServiceImpl implements BreedService {

     @Autowired
    BreedsMapper breedsMapper;
    @Override
    public List<Breeds> IdList(int parent_class) {
        return breedsMapper.IdList(parent_class);
    }
}
