package com.service.Impl;

import com.dao.DogGoodsMapper;
import com.pojo.DogGoods;
import com.service.DogGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DogGoodServiceImpl implements DogGoodsService {
    @Autowired
    DogGoodsMapper dogGoodsMapper;
    @Override
    public List<DogGoods> top10() {
        return dogGoodsMapper.top10();
    }

    @Override
    public List<DogGoods> list() {
        return dogGoodsMapper.list();
    }

    @Override
    public DogGoods getId(int id) {
        return dogGoodsMapper.getId(id);
    }

    @Override
    public List<DogGoods> MultGetId(List list) {
        return dogGoodsMapper.MultGetId(list);
    }
}
