package com.service.Impl;

import com.dao.UserMapper;
import com.pojo.User;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserMapper userMappers;

    @Override
    public Integer login(String name, String pwd) {
        return userMappers.login(name,pwd);
    }

    @Override
    public User queryuser(String name) {
        return userMappers.queryuser(name);
    }

    @Override
    public int update(User user) {
        return userMappers.update(user);
    }
}
