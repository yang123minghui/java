package com.service.Impl;

import com.dao.ShoppingMapper;
import com.pojo.Shopping;
import com.service.ShoppingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingImpl implements ShoppingService {
    @Autowired
    ShoppingMapper shoppingMapper;
    @Override
    public int addShopping(String name, int goodsID, int number, String date) {
        return shoppingMapper.addShopping(name,goodsID,number,date);
    }

    @Override
    public Integer selectID(Integer goodsID, String name) {
        return shoppingMapper.selectID(goodsID,name);
    }

    @Override
    public int updateID(Integer goodsID, String name) {
        return shoppingMapper.updateID(goodsID,name);
    }

    @Override
    public int updateIDjiang(Integer goodsID, String name) {
        return shoppingMapper.updateIDjiang(goodsID,name);
    }

    @Override
    public List<Shopping> ListShopping(String name) {
        return shoppingMapper.ListShopping(name);
    }

    @Override
    public List<Shopping> queryprice(String name, List goodsID) {
        return shoppingMapper.queryprice(name,goodsID);
    }
}
