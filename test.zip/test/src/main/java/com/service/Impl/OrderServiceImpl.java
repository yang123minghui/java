package com.service.Impl;

import com.dao.OrderMapper;
import com.pojo.Order;
import com.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    OrderMapper orderMapper;
    @Override
    public int baocun(Order order) {
        return orderMapper.baocun(order);
    }

    @Override
    public List<Order> listOrder(String name) {
        return orderMapper.listOrder(name);
    }

    @Override
    public int deleteOrder(String ordernumber) {
        return orderMapper.deleteOrder(ordernumber);
    }

    @Override
    public int updateOrder(String ordernumber) {
        return orderMapper.updateOrder(ordernumber);
    }

    @Override
    public List<Order> queryOrder(String name, int status) {
        return orderMapper.queryOrder(name,status);
    }


}
