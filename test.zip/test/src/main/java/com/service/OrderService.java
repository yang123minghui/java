package com.service;

import com.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderService {
//    保存订单
    int baocun(Order order);
    //    查询全部
    List<Order> listOrder(String name);
    //    删除订单
    int deleteOrder(String ordernumber);
    //    跟新
    int updateOrder(String ordernumber);
    //   status条件查询
    List<Order>queryOrder(@Param("name")String name,@Param("status") int status);
}
