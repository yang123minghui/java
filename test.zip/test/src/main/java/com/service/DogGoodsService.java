package com.service;

import com.pojo.DogGoods;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DogGoodsService {
    List<DogGoods> top10();
    List<DogGoods>list();
    DogGoods getId(int id);
    List<DogGoods> MultGetId(@Param("MultiId")List list);
}
