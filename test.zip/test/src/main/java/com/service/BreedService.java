package com.service;

import com.pojo.Breeds;

import java.util.List;

public interface BreedService {
    List<Breeds> IdList(int parent_class);
}
