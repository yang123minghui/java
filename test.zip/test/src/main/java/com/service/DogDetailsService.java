package com.service;

import com.pojo.DogDetails;

public interface DogDetailsService {
    DogDetails getDetails(String dogname);
}
