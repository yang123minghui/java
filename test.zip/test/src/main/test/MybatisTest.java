import com.dao.*;


import com.pojo.DogGoods;
import com.pojo.Order;
import com.pojo.OrderItem;
import com.pojo.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring/applicationContext.xml")
public class MybatisTest {
    @Autowired
    UserMapper userMappers;
    @Autowired
    BreedsMapper breedsMapper;
    @Autowired
    DogDetailsMapper dogDetailsMapper;
    @Autowired
    DogGoodsMapper dogGoodsMapper;
    @Autowired
    ShoppingMapper shoppingMapper;
    @Autowired
    OrderMapper orderMapper;
    @Autowired
    OrderItemMapper orderItemMapper;
    @Test
    public void te(){

        List<Order> update = orderMapper.queryOrder("admin",1);

    }
}
